# SuperKart — Full-Code (Synced Template)

This repo mirrors the **Full-Code learner template** section-by-section (1–9) and includes:
- Notebook aligned to rubric & ready to run with `/mnt/data/SuperKart.csv`.
- Backend Flask API (Docker) + Frontend Streamlit app.
- Final model saved to `model/pipeline.joblib`.

## Deploy (HF Spaces)
1) Backend (Docker): upload `api/` + your `model/` folder (after training locally).
2) Frontend (Streamlit): upload `app/`, set `BACKEND_URL` secret to `<backend>/predict`.
3) Paste both links into Section 6 & 7 of the notebook.
