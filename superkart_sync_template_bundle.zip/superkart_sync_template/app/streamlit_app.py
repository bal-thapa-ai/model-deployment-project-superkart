import os, requests, streamlit as st

st.set_page_config(page_title="SuperKart Predictor", layout="centered")
st.title("🛒 SuperKart — Sales Revenue Predictor")
st.caption("Predicts Product_Store_Sales_Total")

BACKEND_URL = os.environ.get("BACKEND_URL", "https://your-backend-space.hf.space/predict")

with st.form("form"):
    Product_Weight = st.number_input("Product_Weight", min_value=0.0, value=1.0, step=0.1)
    Product_Allocated_Area = st.number_input("Product_Allocated_Area", min_value=0.0, max_value=1.0, value=0.1, step=0.01)
    Product_MRP = st.number_input("Product_MRP", min_value=0.0, value=100.0, step=1.0)
    Store_Establishment_Year = st.number_input("Store_Establishment_Year", min_value=1950, max_value=2030, value=2010, step=1)
    Product_Sugar_Content = st.selectbox("Product_Sugar_Content", ["low","regular","no sugar"])
    Product_Type = st.selectbox("Product_Type", ["meat","snack foods","hard drinks","dairy","canned","soft drinks","health and hygiene","baking goods","bread","breakfast","frozen foods","fruits and vegetables","household","seafood","starchy foods","others"])
    Store_Size = st.selectbox("Store_Size", ["low","medium","high"])
    Store_Location_City_Type = st.selectbox("Store_Location_City_Type", ["Tier 1","Tier 2","Tier 3"])
    Store_Type = st.selectbox("Store_Type", ["Departmental Store","Supermarket Type 1","Supermarket Type 2","Food Mart"])
    submitted = st.form_submit_button("Predict")

if submitted:
    payload = {
        "Product_Weight": Product_Weight,
        "Product_Allocated_Area": Product_Allocated_Area,
        "Product_MRP": Product_MRP,
        "Store_Establishment_Year": int(Store_Establishment_Year),
        "Product_Sugar_Content": Product_Sugar_Content,
        "Product_Type": Product_Type,
        "Store_Size": Store_Size,
        "Store_Location_City_Type": Store_Location_City_Type,
        "Store_Type": Store_Type
    }
    try:
        resp = requests.post(BACKEND_URL, json=payload, timeout=30)
        resp.raise_for_status()
        pred = resp.json().get("predictions", [None])[0]
        st.success(f"Predicted Product_Store_Sales_Total: **{pred:.2f}**" if pred is not None else "No prediction returned.")
    except Exception as e:
        st.error(f"Request failed: {e}")
        st.info("Check that your backend Space is public and BACKEND_URL is correct.")
