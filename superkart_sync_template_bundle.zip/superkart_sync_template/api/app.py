from flask import Flask, request, jsonify
import joblib, os

app = Flask(__name__)
_pipeline = None

def get_pipeline():
    global _pipeline
    if _pipeline is None:
        path = os.environ.get("PIPELINE_PATH", "model/pipeline.joblib")
        _pipeline = joblib.load(path)
    return _pipeline

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict")
def predict():
    data = request.get_json(force=True)
    rows = data if isinstance(data, list) else [data]
    pipe = get_pipeline()
    preds = pipe.predict(rows).tolist()
    return jsonify({"predictions": preds})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 7860)))
